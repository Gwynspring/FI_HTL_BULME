/*
 * ADU.h
 *
 * Created: 14.10.2024 17:57:37
 *  Author: gspur
 */ 

#ifndef ADU_ATMEGA2560_ADDON_BOARD_H
#define ADU_ATMEGA2560_ADDON_BOARD_H

void ADU_Init();
short ADU_Read(char ADU_channel);

#endif